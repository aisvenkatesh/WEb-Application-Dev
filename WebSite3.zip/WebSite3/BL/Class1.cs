﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;
using static DL.Class1;

namespace BL
{
    public class Class1
    {
    }
    public class CLSBAL
    {
        CLSDataLayer cLSData = new CLSDataLayer();
        public object employeeCheck(string name)
        {
            return cLSData.IsValidEmployee(name);
        }
    }
}
