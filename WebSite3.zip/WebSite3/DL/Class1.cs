﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static DL.Class1;
using System.Configuration;
using System.Linq.Expressions;
using System.Data.Linq.Mapping;
 

namespace DL
{
    public class Class1
    {
        public class CLSDataLayer
        {
            public object IsValidEmployee(string name)
            {
                DataClasses1DataContext myDB = new DataClasses1DataContext();
                var userResults = from a in myDB.Employees
                                  where a.Name.Equals(name)
                                  select a;

                return userResults;
            }
        }
    }
}
