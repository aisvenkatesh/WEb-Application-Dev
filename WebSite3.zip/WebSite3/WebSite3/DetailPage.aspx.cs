﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DetailPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox2.Text = Session["ID"].ToString();
        TextBox3.Text = Session["Name"].ToString();
        TextBox4.Text = Session["Age"].ToString();
        TextBox5.Text = Session["City"].ToString();
        TextBox6.Text = Session["State"].ToString();
        TextBox7.Text = Session["Attendance"].ToString();
        int value;
        if (Int32.TryParse(TextBox7.Text, out value))
        {
            if (value < 70)
            {
                Label8.ForeColor = System.Drawing.Color.Red;
                Label8.BackColor = System.Drawing.Color.LightBlue;
                Label8.Text = "Attendance is below 70 percent";

            }

            else if (value > 90)
            {
                Label8.ForeColor = System.Drawing.Color.Green;
                Label8.BackColor = System.Drawing.Color.LightBlue;
                Label8.Text = "Attendance is above 90 percent";

            }
            else if (value > 70 && value < 90)
            {
                Label8.ForeColor = System.Drawing.Color.Yellow;
                Label8.BackColor = System.Drawing.Color.LightBlue;
                Label8.Text = "Attendance percentage needs improvement";

            }
        }

    }

}