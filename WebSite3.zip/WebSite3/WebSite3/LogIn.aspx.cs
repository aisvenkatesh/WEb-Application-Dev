﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Runtime.InteropServices;
using BL;
using static DL.Class1;
using DL;

public partial class LogIn : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        CLSDataLayer cLSData = new CLSDataLayer();
        DataClasses1DataContext myDB = new DataClasses1DataContext();
        var result = (from a in myDB.Userdatas
                      where a.UserName.Equals(TextBoxUN.Text) && a.Password.Equals(TextBox4.Text)
                      select a);

        if (result.Count()>0)
        {
            Response.Redirect("Search.aspx");
        }
        else
        {
            Response.Write("Invalid Credentials");
        }   
    }
}