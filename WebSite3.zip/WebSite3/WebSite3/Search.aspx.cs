﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.Linq;
using System.Linq.Expressions;
using System.Data.Linq.Mapping;
using DL;
using BL;
using System.Xml.Linq;

public partial class Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        CLSBAL cLSBAL = new CLSBAL();
        GridView1.DataSource = cLSBAL.employeeCheck(TextBox1.Text);
        GridView1.DataBind();
        if (GridView1.Rows.Count == 0)
        {
            Response.Write("The entered employee detail is not present in the database");
        }

    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        Session["ID"] = gr.Cells[1].Text;
        Session["Name"] = gr.Cells[2].Text;
        Session["Age"] = gr.Cells[3].Text;
        Session["City"] = gr.Cells[4].Text;
        Session["State"] = gr.Cells[5].Text;
        Session["Attendance"] = gr.Cells[6].Text;
        Response.Redirect("DetailPage.aspx");
    }
}
        
